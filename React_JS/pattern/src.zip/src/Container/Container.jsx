const Container = props => props.children;

export default Container;